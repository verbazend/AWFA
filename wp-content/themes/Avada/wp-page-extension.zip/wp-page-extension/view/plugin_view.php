<?php

echo '<h1>Plugin View </h1>';

?>